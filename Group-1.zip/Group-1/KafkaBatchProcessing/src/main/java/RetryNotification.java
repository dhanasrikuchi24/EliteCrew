import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class RetryNotification {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder().appName("RetryNotification").config("spark.master", "local").getOrCreate();
        /*Reading from kafka topic having data in json format*/
        Dataset<Row> kafka_json_df = spark.read().format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "retry_notification").load();
        kafka_json_df.printSchema();
        Dataset<Row> failedOrders = kafka_json_df.selectExpr("CAST(value AS STRING) as value");


        JavaRDD<String> transformedRdd = failedOrders.toJavaRDD().map(x -> x.mkString());
        Dataset<Row> order_json = spark.read().json(transformedRdd);

        order_json.repartition(1).write().mode("overwrite").format("com.databricks.spark.csv").option("header","true").save("data/failed_orders.csv");


    }
}
