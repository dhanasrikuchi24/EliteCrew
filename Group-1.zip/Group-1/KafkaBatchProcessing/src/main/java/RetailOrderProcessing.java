
import org.apache.spark.sql.*;

import java.io.IOException;

import static org.apache.spark.sql.functions.*;


public class RetailOrderProcessing {
    public static void main(String[] args) throws IOException {

        SparkSession spark = SparkSession.builder().appName("OrderProcessingApp").config("spark.master", "local").getOrCreate();
        String schemas = "partition long,offset long";

        /*Creating a spark dataframe from csv*/
        Dataset<Row> csvDf = spark.read().option("header", "true").csv("data/Retail_Data.csv");

        System.out.println("csvCount:"+csvDf.count());
        //csvDf.show(10);

        Dataset<Row> successOrders = csvDf.filter(col("Status").equalTo("S"));
        Dataset<Row> failureOrders = csvDf.filter(col("Status").equalTo("F"));

        int SuccessCount = (int) csvDf.filter(col("Status").equalTo("S"))
                .count();

        int FailureCount = (int) csvDf.filter(col("Status").equalTo("F"))
                .count();

        System.out.println("Success: " + SuccessCount);
        System.out.println("Failure: " + FailureCount);

        /*Writing csvDf dataframe into kafka in json format (Kafka Sink)*/
        Dataset<Row> successOrdersJson = successOrders.selectExpr("to_json(struct(*)) AS value");
        successOrdersJson.write().format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("topic", "order_evaluation").save();

        Dataset<Row> failureOrdersJson = failureOrders.selectExpr("to_json(struct(*)) AS value");
        failureOrdersJson.write().format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("topic", "retry_notification").save();


    }
}
