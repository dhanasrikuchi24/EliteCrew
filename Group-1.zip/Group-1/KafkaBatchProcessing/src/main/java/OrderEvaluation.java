import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.*;
import org.apache.spark.sql.types.DataTypes;

public class OrderEvaluation {
    public static void main(String[] args) {

        //String schemas = "partition long,offset long";

        SparkSession spark = SparkSession.builder().appName("OrderEvaluation").config("spark.master", "local").getOrCreate();
        /*Reading from kafka topic having data in json format*/
        Dataset<Row> kafka_json_df = spark.read().format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "order_evaluation").load();
        kafka_json_df.printSchema();
        Dataset<Row> sucessOrdersdf = kafka_json_df.selectExpr("CAST(value AS STRING) as value");
        //sucessOrdersdf.show(10);

        JavaRDD<String> transformedRdd = sucessOrdersdf.toJavaRDD().map(x -> x.mkString());
        Dataset<Row> order_json = spark.read().json(transformedRdd);
        //order_json.show(10);

        Dataset<Row> x = order_json.filter(order_json.col("List_Price").cast(DataTypes.IntegerType).geq(50));

        x.show(10);
        System.out.println("order123x:"+ x.count());

        x.repartition(1).write().mode("overwrite").format("com.databricks.spark.csv").option("header","true").save("data/above_50.csv");

        Dataset<Row> y = order_json.filter(order_json.col("Brand").cast(DataTypes.StringType).contains("Equate"));

        y.show(10);
        System.out.println("order123y:"+ y.count());

        y.repartition(1).write().mode("overwrite").format("com.databricks.spark.csv").option("header","true").save("data/equate.csv");
    }
}
